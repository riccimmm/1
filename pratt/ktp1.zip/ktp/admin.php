<?php
include'header.php';
if ($provlog==$_SESSION['log'] && $provpar==md5($_SESSION['par']) && $_SESSION['log']!="" && md5($_SESSION['par'])!=""){}else{echo'Только для зареганых'; include'footer.php'; exit;} if($dostup==101 || $dostup==102){
switch($_GET['act']){
default:
$tug=file_get_contents('tmp/tur.dat');
echo'<b>Панель управления</b><br/><br>Сейчас идёт<b> '.$tug.'</b> тур<br/>&#187; <a href="admin.php?act=dobnews">Добавить новость</a><br>&#187; <a href="admin.php?act=next_tur">Следующий тур</a><hr>&#187; <a href="admin.php?act=dobmatch">Добавить матч</a><br>&#187; <a href="admin.php?act=gom">Провести матч</a><br>';
break;
case'dobnews':
if(!empty($_POST['name']) and !empty($_POST['text'])){
$text=prov($_POST['text']);
$name=prov($_POST['name']);
mysql_query("INSERT INTO `ktp_news` SET `name`='$name', `text`='$text', `uz`='$log', `time`='$sitetime'"); echo'Успешно добавлено!';
}else{
echo'<form action="admin.php?act=dobnews" method="post">Название:<br><input type="text" name="name" size="18"><br>Текст:<br><textarea cols="20" rows="3" name="text"></textarea><br><input type="submit" value="Добавить"/></form>';
}
break;
case'next_tur': $dd=file_get_contents('tmp/tur.dat');
echo'Добавление туров  нужно чтобы в них добавлять матчи,в один тур можна добавить сколько хочеш матчей! На данный момент идет '.$dd.' тур<br><a href="admin.php?act=next_tur2">Добавить следующий тур</a>';
break;
case'next_tur2': $pp=file_get_contents('tmp/tur.dat')+1;
file_put_contents('tmp/tur.dat',$pp);
$pg=file_get_contents('tmp/tur.dat'); echo'Добавлен '.$pg.' тур, пожалуйста добавте в него матчи';
break;
case'dobmatch':
if(!empty($_POST['k1']) and !empty($_POST['k2']) and !empty($_POST['konec']) and !empty($_POST['den']) and !empty($_POST['mes'])){
$den=(int)$_POST['den'];
$mes=(int)$_POST['mes'];
$tur=file_get_contents('tmp/tur.dat');
$konec=prov($_POST['konec']); $k2=prov($_POST['k2']);
$k1=prov($_POST['k1']);
$z=explode(':',$konec);
$mktime=mktime($z[0],$z[1],date('s'),$mes,$den,2010);
mysql_query("INSERT INTO `ktp_match` SET `k1`='$k1', `k2`='$k2', `konec`='$mktime', `tur`='$tur'");

echo'Матч '.prov($k1).' vs '.prov($k2).'<br>добавлен, ставки принимаются до '.date('d.m.y/H:i:s',$mktime);
}else{
echo'Сейчас: '.date('d.m.y/H:i').'<br/><form action="admin.php?act=dobmatch" method="post">Команда1:Команда2<br/><center><input type="text" name="k1" size="18"><br>:<br><input type="text" name="k2" size="18"></center>Введите дату до которой принимаются ставки:<br>день|месяц/часы:минуты<br><select name="den">';

for($i=1; $i<32; $i++){
echo'<option value="'.$i.'">'.$i.'</option>';} echo'</select><select name="mes">';
for($x=1; $x<13; $x++){
echo'<option value="'.$x.'">'.$x.'</option>';} echo'</select> <input type="text" name="konec" size="5" value=":"><br><input type="submit" value="Добавить"/></form>';

}
break;

case'gom': $tur=file_get_contents('tmp/tur.dat'); $total=mysql_result(mysql_query("SELECT COUNT(*) FROM `ktp_match` WHERE `tur`='$tur' AND (`s1`='' OR `s2`='') ORDER BY `id`"),0); if($total!=0){$query=mysql_query("SELECT * FROM `ktp_match` WHERE `tur`='$tur' AND (`s1`='' OR `s2`='') ORDER BY `id` DESC");
 while($data=mysql_fetch_array($query)){
echo'<div class="b">'.$data['k1'].':'.$data['k2'].'<br><a href="admin.php?act=gom2&amp;id_match='.$data['id'].'">Завершить матч</a></div>';
 }
 }else{echo'Матчей нет';} break; case'gom2':  $id_match=(int)$_GET['id_match'];
  $qry=mysql_num_rows(mysql_query("SELECT * FROM `ktp_match` WHERE `id`='$id_match' LIMIT 1"));  if($qry==0){echo'Нет такого матча';}else{ if(!empty($_POST['s1']) and !empty($_POST['s2'])){
 $s2=(int)$_POST['s2'];
 $s1=(int)$_POST['s1'];
 mysql_query("UPDATE `ktp_match` SET `s1`='$s1', `s2`='$s2' WHERE `id`='$id_match'");   $query=mysql_query("SELECT * FROM `ktp_play` WHERE `id_match`='$id_match'");  while($wd=mysql_fetch_array($query)){  if($s1==$wd['s1'] and $s2==$wd['s2']){ mysql_query("UPDATE `ktp_user` SET `ochki`=`ochki`+3, `t1`=`t1`+1 WHERE `uz`='".$wd['uz']."'"); mysql_query("UPDATE `ktp_club` SET `ochki`=`ochki`+3, `t1`=`t1`+1 WHERE `id`='".$wd['id_club']."'");   } if(($s1>$wd['s1'] and $s2>$wd['s2']) or ($s1<$wd['s1'] and $s2<$wd['s2'])){ mysql_query("UPDATE `ktp_user` SET `ochki`=`ochki`+1, `t2`=`t2`+1 WHERE `uz`='".$wd['uz']."'"); mysql_query("UPDATE `ktp_club` SET `ochki`=`ochki`+1, `t2`=`t2`+1 WHERE `id`='".$wd['id_club']."'");   }
if(($s1>$wd['s1'] and $s2>$wd['s2']) or ($s1<$wd['s1'] and $s2<$wd['s2']) or ($s1==$wd['s1'] and $s2==$wd['s2'])){}else{ mysql_query("UPDATE `ktp_user` SET `t3`=`t3`+1 WHERE `uz`='".$wd['uz']."'"); mysql_query("UPDATE `ktp_club` SET `t3`=`t3`+1 WHERE `id`='".$wd['id_club']."'");}     } echo'Матч проведен!';
   }else{ $da=mysql_fetch_assoc(mysql_query("SELECT `k1`,`k2` FROM `ktp_match` WHERE `id`='$id_match' LIMIT 1"));
 echo'Матч '.$da['k1'].':'.$da['k2'].'<br/><form action="admin.php?act=gom2&amp;id_match='.$id_match.'" method="post"><input type="text" name="s1" size="2"> : <input type="text" name="s2" size="2"><br><input type="submit" value="Провести"/></form>';
 }}
 break; }}else{header("Location:../index.php");}

include'footer.php';
?>
