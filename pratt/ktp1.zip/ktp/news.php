<?php
include'header.php';
$total=mysql_result(mysql_query("SELECT COUNT(*) FROM `ktp_news`"),0); if($total!=0){$page = abs((int)$_GET['page']);

if($page < 0 || $page > $total) $page = 0;

if ($total < $page + 8) $end = $total;
else $end = $page + 8;
$query=mysql_query("SELECT * FROM `ktp_news` ORDER BY `id` DESC LIMIT $page,8");
while($data=mysql_fetch_array($query)){
echo'<div class="b">'.smiles($data['name']).'</div>'.smiles($data['text']).'<br>Добавил: '.$data['uz'].'<br>';
}
strpage($page, 8, $total, "news.php");
}else{echo'Новостей еще не было';} include'footer.php';
?>
