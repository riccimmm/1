-- phpMyAdmin SQL Dump
-- version 3.4.9
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Фев 24 2012 г., 12:56
-- Версия сервера: 5.1.56
-- Версия PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `xays466_john`
--

-- --------------------------------------------------------

--
-- Структура таблицы `ktp`
--

CREATE TABLE IF NOT EXISTS `ktp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tip` tinyint(1) NOT NULL,
  `ext1` int(11) NOT NULL,
  `ext2` varchar(255) NOT NULL,
  `ext3` varchar(255) NOT NULL,
  `ext4` varchar(255) NOT NULL,
  `ext5` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=39 ;

--
-- Дамп данных таблицы `ktp`
--

I
--
-- Структура таблицы `ktp_club`
--

CREATE TABLE IF NOT EXISTS `ktp_club` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `abb` text NOT NULL,
  `uz` text NOT NULL,
  `time` bigint(60) NOT NULL,
  `ochki` bigint(30) NOT NULL,
  `stavki` bigint(30) NOT NULL,
  `t1` bigint(30) NOT NULL,
  `t2` bigint(30) NOT NULL,
  `t3` bigint(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Структура таблицы `ktp_match`
--

CREATE TABLE IF NOT EXISTS `ktp_match` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `k1` text NOT NULL,
  `k2` text NOT NULL,
  `s1` int(10) NOT NULL,
  `s2` int(10) NOT NULL,
  `konec` bigint(60) NOT NULL,
  `tur` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Структура таблицы `ktp_news`
--

CREATE TABLE IF NOT EXISTS `ktp_news` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `uz` varchar(155) NOT NULL,
  `name` text NOT NULL,
  `text` text NOT NULL,
  `time` bigint(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Структура таблицы `ktp_play`
--

CREATE TABLE IF NOT EXISTS `ktp_play` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `uz` text NOT NULL,
  `s1` int(10) NOT NULL,
  `s2` int(10) NOT NULL,
  `id_match` int(20) NOT NULL,
  `id_club` int(20) NOT NULL,
  `time` bigint(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `ktp_user`
--

CREATE TABLE IF NOT EXISTS `ktp_user` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `uz` text NOT NULL,
  `id_club` int(30) NOT NULL,
  `time` bigint(60) NOT NULL,
  `ochki` int(30) NOT NULL,
  `stavki` int(30) NOT NULL,
  `t1` int(30) NOT NULL,
  `t2` int(30) NOT NULL,
  `t3` int(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Структура таблицы `ktp_vstup`
--

CREATE TABLE IF NOT EXISTS `ktp_vstup` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `uz` text NOT NULL,
  `id_club` int(30) NOT NULL,
  `time` bigint(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
