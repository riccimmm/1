<?php

//}else{echo'Для пользования этим разделом,нужно сперва зарегистрироватся на сайте!';}


include_once "../themes/$config_themes/foot.php"; ?>
