<?php
include'header.php';
$total=mysql_result(mysql_query("SELECT COUNT(*) FROM `ktp_club` ORDER BY `ochki`"),0); $page = abs((int)$_GET['page']);

if($page < 0 || $page > $total) $page = 0;

if ($total < $page + 10) $end = $total;
else $end = $page + 10;
$query=mysql_query("SELECT * FROM `ktp_club` ORDER BY `ochki` DESC LIMIT $page,10");
echo'<img src="../images/img/4.jpeg" alt=""<br><br>';
echo'<b>О</b>-очки<br><b>С</b>-ставки<br><b>Т</b>-точный счет<br><b>И</b>-исход<br><b>П</b>-поражений<br/><br><table border="1" cellspacing="1" cellpadding="2"><tr bgcolor="ffffff"><td align="center">#</td><td width="40%" align="center">Команда</td><td align="center">О</td><td align="center">С</td><td align="center">Т</td><td align="center">И</td><td align="center">П</td></tr>'; while($data=mysql_fetch_array($query)){ $kol++;
echo'<tr bgcolor="ffffff"><td align="center">'.$kol.'</td><td  width="40%" align="center"><a href="info.php?id_club='.$data['id'].'">'.$data['name'].'</td><td align="center">'.$data['ochki'].'</td><td align="center">'.$data['stavki'].'</td><td align="center">'.$data['t1'].'</td><td align="center">'.$data['t2'].'</td><td align="center">'.$data['t3'].'</td></tr>';
} echo'</table>';

strpage($page, 10, $total, "rating_club.php");
include'footer.php';
?>