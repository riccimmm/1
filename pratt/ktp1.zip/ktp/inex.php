<?php
include'header.php';

if ($provlog==$_SESSION['log'] && $provpar==md5($_SESSION['par']) && $_SESSION['log']!="" && md5($_SESSION['par'])!=""){
$tur=file_get_contents('tmp/tur.dat');
switch($_GET['act']){
default: $q=mysql_query("SELECT `time` FROM `ktp_news` ORDER BY `id` DESC LIMIT 1");
if(mysql_num_rows($q)==0){$news_q='нет';}else{$et=mysql_fetch_assoc($q); $news_q=date_fixed($et['time']);}

$match_q=mysql_result(mysql_query("SELECT COUNT(*) FROM `ktp_match` WHERE `tur`='$tur'"),0);
echo'&#187; <a href="index.php?act=rules">Информация</a><br>&#187; <a href="news.php">Новости</a> [<font color="red">'.$news_q.'</font>]<br>&#187; <a href="rating_user.php">Рейтинг игроков</a><br>&#187; <a href="rating_club.php">Рейтинг команд</a><br>&#187; <a href="tur.php">Обзор туров</a><br>&#187; <a href="cabinet.php">Личный кабинет</a><br>&#187; <a href="index.php?act=play">Выставленые матчи</a> ['.$match_q.']<br>'; if($dostup==101 || $dostup==102){echo'<br>&#187; <a href="admin.php">Админ панель</a><br>';}
break;

case'play':
$qg1=mysql_num_rows(mysql_query("SELECT * FROM `ktp_club` WHERE `uz`='$log' LIMIT 1"));
$qg2=mysql_num_rows(mysql_query("SELECT * FROM `ktp_user` WHERE `uz`='$log' LIMIT 1"));
if($qg2==0 or $qg1==0){echo'У вас нет команды';}else{
$bb=mysql_fetch_assoc(mysql_query("SELECT `id_club` FROM `ktp_user` WHERE `uz`='$log' LIMIT 1"));
$gg=mysql_num_rows(mysql_query("SELECT * FROM `ktp_user` WHERE `id_club`='".$bb['id_club']."'"));
if($gg<=2){echo'Чтоб делать ставки , надо чтоб в команде было не меньше двух игроков,не считая капитана';}else{
echo'Сейчас <b>'.$tur.'</b> тур<br/><br>';
$tota=mysql_result(mysql_query("SELECT COUNT(*) FROM `ktp_match` WHERE `tur`='$tur'"),0); if($tota!=0){
$query=mysql_query("SELECT * FROM `ktp_match` ORDER BY `id` DESC"); while($data=mysql_fetch_array($query)){ echo $data['k1'].':'.$data['k2'].'<br><b>Принимаются до: </b>'.date_fixed($data['konec']).'<br>';
if($data['konec']>$sitetime){
$qu=mysql_num_rows(mysql_query("SELECT * FROM `ktp_play` WHERE `id`='".$data['id']."' LIMIT 1"));
if($qu==0){echo'<a href="index.php?act=play2&amp;id='.$data['id'].'">[Сделать ставку]</a>';
}else{echo'<font color="blue">[Ставка сделана]</font>';}
}else{echo'<font color="red">[Ставки не принимаются]</font>';} echo'<br>';}
}else{echo'Матчей еще нет';}
}} break;
case'play2':

$qg1=mysql_num_rows(mysql_query("SELECT * FROM `ktp_club` WHERE `uz`='$log' LIMIT 1"));
$qg2=mysql_num_rows(mysql_query("SELECT * FROM `ktp_user` WHERE `uz`='$log' LIMIT 1"));
if($qg2==0 or $qg1==0){echo'У вас нет команды';}else{
$bb=mysql_fetch_assoc(mysql_query("SELECT `id_club` FROM `ktp_user` WHERE `uz`='$log' LIMIT 1"));
$gg=mysql_num_rows(mysql_query("SELECT * FROM `ktp_user` WHERE `id_club`='".$bb['id_club']."'"));
if($gg<=2){echo'Чтоб делать ставки,нада чтоб в команде было не меньше двух игроков,не считая капитана';}else{ $id=(int)$_GET['id'];
$qe=mysql_num_rows(mysql_query("SELECT * FROM `ktp_match` WHERE `id`='$id' LIMIT 1"));
if($qe==1){
if(!empty($_POST['s1']) and !empty($_POST['s2'])){ $s1=(int)$_POST['s1']; $s2=(int)$_POST['s2'];
$id_c=mysql_fetch_assoc(mysql_query("SELECT `id_club` FROM `ktp_user` WHERE `uz`='$log' LIMIT 1"));
mysql_query("INSERT INTO `ktp_play` SET `s1`='$s1', `s2`='$s2', `id_club`='".$id_c['id_club']."', `time`='$sitetime', `uz`='$log'");
$qtp=mysql_fetch_assoc(mysql_query("SELECT `id_club` FROM `ktp_user` WHERE `uz`='$log' LIMIT 1"));
mysql_query("UPDATE `ktp_user` SET `stavki`=`stavki`+1 WHERE `uz`='$log'"); mysql_query("UPDATE `ktp_club` SET `stavki`=`stavki`+1 WHERE `uz`='".$qtp['id_club']."'");
echo'Ставка принята';}else{

$data=mysql_fetch_assoc(mysql_query("SELECT `k1`,`k2` FROM `ktp_match` WHERE `id`='$id' LIMIT 1"));
echo'<form action="index.php?act=play2&amp;id='.$id.'" method="post">'.$data['k1'].':'.$data['k2'].'<br><input type="text" name="s1" size="2" value="0">:<input type="text" name="s2" size="2" value="0"><br><input type="submit" value="Поставить"/></form>';
}}else{echo'Нет такого матча!';}}}
break; case'rules': echo'Это командный турнир прогнозистов, суть такова: каждый может вступить в команду,или создать свою, в команду входит 5человек с капитано, каждый игрок команды,ставит на матч и получает: за правельно спрогнозированый счет 3очка, за угаданый исход матча 1очко себе и своей команде.В конце сезона будут подведены итоги,где лучшие получат призы!С уважением администрация сайта:) '; break;
}}else{echo'Только для зарегистрированых';} include'footer.php';
?>
