<?php



/*

CREATE TABLE IF NOT EXISTS `ktp` (
`id` int(11) NOT NULL auto_increment,
`tip` tinyint(1) NOT NULL,
`ext1` int(11) NOT NULL,
`ext2` varchar(255) NOT NULL,
`ext3` varchar(255) NOT NULL,
`ext4` varchar(255) NOT NULL,
`ext5` varchar(255) NOT NULL,
PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
*/


//"Агрегатная" часть присваивания


function chat($user, $time, $text, $id)
{
    $q = mysql_fetch_row(mysql_query('select `name` from `users` where `id`=\'' . $user .
        '\''));
    global $set_user;
    echo '<div class="list1"><a href="users/profile.php?user=' . $user . '">' . $q[0] .
        '</a> ' . date("(d.m.Y / H:i)", $time + $set_user['sdvig'] * 3600);
    echo ADMIN ? ' <a href="?act=delmes&amp;id=' . $id . '">(уд)</a>' : '';
    if ($set_user['smileys'])
        $text = fchat(functions::smileys($text, ADMIN));

    ///echo '<br/>',tags($text),'</div>';
    echo '<br/>', $text, '</div>';
}

//испр. пути к смайлам из за стандартной функции
function fchat($t)
{
    return strtr($t, array('<img src="../' => '<img src="'));
}

//выводит ник
function unik($id)
{
    $q = mysql_fetch_row(mysql_query('select `name` from `users` where `id`=\'' . $id .
        '\''));
    return $q[0];
}

//Служебные функции

function main()
{
    echo v2('<a href="ktp.php">Обратно в КТП</a>');
}

function ktp_end()
{
    require('incfiles/end.php');
    exit;
}

function html($i)
{
    return htmlentities($i, ENT_QUOTES, 'UTF-8');
}

function v1($t)
{
    return '<div class="phdr">' . $t . '</div>';
}
function v2($t)
{
    return '<div class="menu">' . $t . '</div>';
}
function v3($t)
{
    return '<div class="tmn">' . $t . '</div>';
}
function v5($t)
{
    return '<div class="rmenu">' . $t . '</div>';
}
function v6($t)
{
    return '<div class="gmenu">' . $t . '</div>';
}
function v7($t)
{
    return '<div class="list1">' . $t . '</div>';
}
function v8($t)
{
    return '<div class="list2">' . $t . '</div>';
}

//"Поехали !" (с) Гагарин ( возможно father lady Gaga's )

if (!isset($_GET['act']))
    $_GET['act'] = false;
//Шапка
define('_IN_JOHNCMS', 1);
global $ktp_title, $headmod, $rootpath;
$headmod = 'КТП'; //
$textl = 'КТП';
// Внимание! Если файл находится в корневой папке, нужно указать $rootpath = '';
$rootpath = '';
require_once ('incfiles/core.php');
require_once ('incfiles/head.php');

//закрываем доступ не авторизованному
if (!$user_id) {
    echo '<div class="rmenu"><p>Доступ к КТП открыт только <a href="login.php">авторизованным</a> посетителям</p></div>';
        require('incfiles/end.php');
}

//вычисляем есть ли юзер в команде,если да,то в какой
$comandos = mysql_query('select * from `ktp` where `tip`=\'4\' and `ext2`=\'' .
    $user_id . '\'');

//управляющий или не управляющий
define('ADMIN', $rights == 9 ? 1 : 0);

//очки - Команде и юзерам
$ochki['result'] = 3; // Очки за угаданный результат
$ochki['razn'] = 2; // Очки за угаданную разницу
$ochki['ishod'] = 1; // Очки за угаданный исход

//установка&удаление
if (ADMIN) {

    if (isset($_GET['uninstall'])) {
        mysql_query("DROP TABLE `ktp`");
        echo v6('Удаление таблицы завершено');
        main();
            require('incfiles/end.php');
    }

    if (isset($_GET['nikolay'])) {
        mysql_query("CREATE TABLE IF NOT EXISTS `ktp` (
	`id` int(11) NOT NULL auto_increment,
  	`tip` tinyint(1) NOT NULL,
  	`ext1` int(11) NOT NULL,
  	`ext2` varchar(255) NOT NULL,
	`ext3` varchar(255) NOT NULL,
	`ext4` varchar(255) NOT NULL,
	`ext5` varchar(255) NOT NULL,
	PRIMARY KEY  (`id`)
	) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");
        echo v6('Установка завершена!');
        main();
            require('incfiles/end.php');
    }
}


// * Сменить условия

if ($_GET['act'] == 'create_comand' and ADMIN) {

    if (!isset($_POST['change'])) {
        echo v1('Создание команды');
        echo '<form action="?act=create_comand" method="POST">';
        echo '<p>Введите название команды<br/>
		<textarea rows="1" cols="50" name="text" ></textarea><br/>
		<small>мин. 5 * макс. 50 симв.</small>
		</p>';
        echo '<p><input type="submit" name="change" value="создать команду"/></p>
		</form>';
        main();
    } else {

        //проверяем пустоту в названии
        if (empty($_POST['text'])) {
            echo v5('Вы не заполнили название создаваемой команды');
            echo '<a href="?act=create_comand">Попытаться снова</a>';
            main();
                require('incfiles/end.php');
        }
        //проверяем длину названия
        if (mb_strlen($_POST['text']) > 50) {
            echo v5('Вы превысили максимальную длину названия команды (' . mb_strlen($_POST['text']) .
                ' &lt; 50)');
            echo '<a href="?act=create_comand">Попытаться снова</a>';
            main();
                require('incfiles/end.php');
        }
        if (mb_strlen($_POST['text']) < 5) {
            echo v5('Вы не набрали минимальную длину названия команды (' . mb_strlen($_POST['text']) .
                ' &lt; 5)');
            echo '<a href="?act=create_comand">Попытаться снова</a>';
            main();
                require('incfiles/end.php');
        }

        //создаем команду
        mysql_query('insert into `ktp` set 
		`tip`=\'1\',
		`ext1`=\'0\',
		`ext2`=\'' . mysql_real_escape_string(html($_POST['text'])) . '\',
		`ext3`=\'' . $user_id . '\',
		`ext4`=\'' . $realtime . '\',
		`ext5`=\'0\'');

        echo v6('Команда успешно создана');
        main();
    }

} elseif ($_GET['act'] == 'inter_comand' and mysql_num_rows($comandos) == 0) {

    if (!isset($_POST['change'])) {
        echo v1('Войти в команду');

        $comand = mysql_query('select * from `ktp` where `tip` = \'1\' ');
        //если команда для вступления еще не создана
        if (!mysql_num_rows($comand)) {
            echo v5('Команды не созданы, сообщите администратору ресурса');
            main();
                require('incfiles/end.php');
        }
        echo '<form action="?act=inter_comand" method="POST">';
        echo v1('Примечание: Если вы вступите в команду где нет капитана, то вы сами станете капитаном команды');

        echo '<select name="text">';
        while ($c = mysql_fetch_assoc($comand)) {
            //если в команде уже более 5-х игроков, то не выводим для входа
            $q = mysql_fetch_row(mysql_query('select count(*) from `ktp` where `tip`=\'4\' and `ext3`=\'' .
                $c['id'] . '\''));
            if ($q[0] < 5)
                echo '<option value="' . $c['id'] . '">' . $c['ext2'] . ' ', ($c['ext5'] ? '' :
                    '(нет кап.)'), '</option>';
        }
        echo '</select>';

        echo v7('<small>Если поле выбора пусто или вам нет что выбрать, дождитесь пока места в командах освободятся</small>');

        echo '<p><input type="submit" name="change" value="вступить в команду"/></p>
		</form>';
        main();
    } else {
        //проверяем пустоту в поле команды
        if (empty($_POST['text'])) {
            echo v5('Вы не выбрали команду');
            echo '<a href="?act=inter_comand">Попытаться снова</a>';
            main();
                require('incfiles/end.php');
        }
        //проверяем цифероверность
        $comand = mysql_query('select * from `ktp` where `tip` = \'1\' and `id`=\'' .
            mysql_real_escape_string($_POST['text']) . '\' ');
        if (!mysql_num_rows($comand)) {
            echo v5('Вы не верно выбрали команду');
            echo '<a href="?act=inter_comand">Попытаться снова</a>';
            main();
                require('incfiles/end.php');
        }
        //проверяеем количество участников
        $q = mysql_fetch_row(mysql_query('select count(*) from `ktp` where `tip`=\'4\' and `ext3`=\'' .
            $c['id'] . '\''));
        if ($q[0] > 5) {
            echo v5('Увы, вы не можете выбрать эту команду, т.к. в ней уже набрано 5 участников');
            echo '<a href="?act=inter_comand">Попытаться снова</a>';
            main();
                require('incfiles/end.php');
        }

        //заносим в команду
        mysql_query('insert into `ktp` set 
		`tip`=\'4\',
		`ext1`=\'' . mysql_real_escape_string('0') . '\',
		`ext2`=\'' . mysql_real_escape_string($user_id) . '\',
		`ext3`=\'' . mysql_real_escape_string($_POST['text']) . '\'
		');
        //если в команде нету капитана, назначаем им его
        $comand = mysql_fetch_assoc($comand);
        if ($comand['ext5'] === '0') {
            mysql_query('update `ktp` set 
				`ext5`=\'' . mysql_real_escape_string($user_id) . '\'
				where `id`=\'' . mysql_real_escape_string($_POST['text']) . '\'
				');
        }
        echo v6('Поздравляю! Вы успешно вступили в команду ' . ($comand['ext5'] === '0' ?
            'и даже стали ее полноправным капитаном. Поздравляю!' : '.'));
        main();
    }

} elseif ($_GET['act'] == 'statcomand' and mysql_num_rows($comandos) == 1) {

    $kolvo = 99; // Максимальное количество команд на вывод

    // *сменить условие на не вывод 0ых очков
    $comands = mysql_query('Select `id` from `ktp` where `tip`=\'1\' order by `ext1` Desc Limit ' .
        $kolvo);

    while ($c = mysql_fetch_assoc($comands)) {
        $q = mysql_result(mysql_query('SELECT sum(ext1) FROM `ktp` WHERE `ext3`=' . $c['id'] .
            ' and `tip`=4'), 0);
        mysql_query('update `ktp` set `ext1`=\'' . $q . '\' where `id`=\'' . $c['id'] .
            '\'');
    }

    $comands = mysql_query('Select * from `ktp` where `tip`=\'1\' order by `ext1` Desc Limit ' .
        $kolvo);

    echo v1('Лучшие команды');
    $mesto = 0;

    //выводим команды
    while ($c = mysql_fetch_assoc($comands)) {

        echo v8(++$mesto . ' место ! <br/>' . $c['ext2'] . ($c['ext5'] ? ' (капитан: ' .
            unik($c['ext5']) . ' )' : '(нет капитана)') . '<br/> Всего очков: ' . $c['ext1']);
        // выводим лучших игроков
        $q = mysql_query('select * from `ktp` where `tip`=\'4\' and `ext3`=\'' . $c['id'] .
            '\' order by `ext1` desc Limit 5');
        //если игроков нету
        if (mysql_num_rows($q) == 0) {
            echo '<small>игроков в команде нет</small>';
        }
        //если есть
        else {
            echo '<small><ul><li>Лучшие игроки</li>';
            while ($u = mysql_fetch_assoc($q)) {
                echo '<li>' . v7(unik($u['ext2']) . ' (очков: ' . $u['ext1'] . ')') . '</li>';
            }
            echo '</ul></small>';
        }
    }
    main();
} elseif ($_GET['act'] == 'statraund' and mysql_num_rows($comandos) == 1) {

    echo v1('Статистика матчей');

    //вывод матчей
    $match = mysql_query('select * from `ktp` where `tip`=\'2\' and `ext4`!=\'0\' order by `ext1` desc Limit 10');
    //если матчей нету
    if (mysql_num_rows($match) == 0) {
        echo v6('Матчей нет.');
        main();
            require('incfiles/end.php');
    }
    while ($m = mysql_fetch_assoc($match)) {
        echo v7($m['ext2'] . ' vs ' . $m['ext3'] . ' ' . $m['ext4']);
        echo '<ul><li>Игроки команд угадавшие результат</li>';
        $q = mysql_query('select * from `ktp` where `tip`=\'5\' and `ext2`=\'' . $m['id'] .
            '\' and `ext3`=\'' . $m['ext4'] . '\' ');
        //если угадавших нету
        if (mysql_num_rows($q) == 0)
            echo '<li>Нету</li>';
        else
            while ($c = mysql_fetch_assoc($q)) {
                echo '<li><b>' . unik($c['ext1']) . '</b></li>';
            }
        echo '</ul>';
    }

    main();
} elseif ($_GET['act'] == 'create_raund' and ADMIN) {

    if (!isset($_POST['change'])) {
        echo v1('Создание матча');
        echo '<form action="?act=create_raund" method="POST">';
        echo '<p>Введите название 1го участника<br/>
		<textarea rows="1" cols="50" name="text" ></textarea><br/>
		<small>мин. 5 * макс. 50 симв.</small>
		</p>';
        echo '<p>Введите название 2го участника<br/>
		<textarea rows="1" cols="50" name="text2" ></textarea><br/>
		<small>мин. 5 * макс. 50 симв.</small>
		</p>';

        echo '<p><b>Дата</b><br /><small>00.00.0000 00:00</small><br /><input type="text" size="20" maxlength="16" name="text3" /></p>';

        echo '<p><input type="submit" name="change" value="создать матч"/></p>
		</form>';
        main();
    } else {

        //проверяем пустоту в названии 1го участника
        if (empty($_POST['text'])) {
            echo v5('Вы не заполнили название создаваемого участника 1');
            echo '<a href="?act=create_raund">Попытаться снова</a>';
            main();
                require('incfiles/end.php');
        }
        //проверяем пустоту в названии 2го участника
        if (empty($_POST['text2'])) {
            echo v5('Вы не заполнили название создаваемого участника 2');
            echo '<a href="?act=create_raund">Попытаться снова</a>';
            main();
                require('incfiles/end.php');
        }
        //проверяем пустоту в временном ограничении
        if (empty($_POST['text3'])) {
            echo v5('Вы не заполнили временное ограничение');
            echo '<a href="?act=create_raund">Попытаться снова</a>';
            main();
                require('incfiles/end.php');
        }
        //проверяем длину названия
        if (mb_strlen($_POST['text']) > 50) {
            echo v5('Вы превысили максимальную длину названия участника 1 (' . mb_strlen($_POST['text']) .
                ' &lt; 50)');
            echo '<a href="?act=create_raund">Попытаться снова</a>';
            main();
                require('incfiles/end.php');
        }
        if (mb_strlen($_POST['text2']) > 50) {
            echo v5('Вы превысили максимальную длину названия участника 2 (' . mb_strlen($_POST['text2']) .
                ' &lt; 50)');
            echo '<a href="?act=create_raund">Попытаться снова</a>';
            main();
                require('incfiles/end.php');
        }


        //создаем матч
        mysql_query('insert into `ktp` set 
		`tip`=\'2\',
		`ext1`=\'' . intval(strtotime($_POST['text3'])) . '\',
		`ext2`=\'' . mysql_real_escape_string(html($_POST['text'])) . '\',
		`ext3`=\'' . mysql_real_escape_string(html($_POST['text2'])) . '\',
		`ext4`=\'0\'
		');

        echo v6('Матч успешно создан');
        main();
    }

} elseif ($_GET['act'] == 'bet' and mysql_num_rows($comandos) == 1 and isset($_GET['id'])) {

    //проверка ид.а
    //на существование и верный тип
    $q = mysql_query('select * from `ktp` where `tip`=\'2\' and `id`=\'' .
        mysql_real_escape_string($_GET['id']) . '\'');
    if (!mysql_num_rows($q)) {
        echo v5('Не верные данные');
        main();
            require('incfiles/end.php');
    }
    //на разрешенную дату для заявки
    $match = mysql_fetch_assoc($q);
    if ($match['ext1'] < $realtime) {
        echo v5('Время для подачи заявок закончилось');
        echo v2('<a href="ktp.php">Обратно в КТП</a>');
        require('incfiles/end.php');
        exit;
    }
    //на уже вынесенный результат
    if ($match['ext4'] != 0) {
        echo v5('Результат матча уже вынесен');
        main();
            require('incfiles/end.php');
    }
    // на сделанную ранее ставку
    $stavka = mysql_query('select * from `ktp` where `tip`=\'5\' and `ext1`=\'' . $user_id .
        '\' and `ext2`=\'' . mysql_real_escape_string($_GET['id']) . '\'');
    if (mysql_num_rows($stavka) == 1) {
        echo v5('Вы уже сделали ставку на данный мачт');
    require_once ("incfiles/end.php");
    exit;
    }

    if (!isset($_POST['change'])) {
        echo v1('Делаем ставку ! <br/> ' . $match['ext2'] . ' vs ' . $match['ext3']);
        echo '<form action="?act=bet&amp;id=' . $_GET['id'] . '" method="POST">';
        echo '<p>Введите предполагаемый счет<br/>';
        echo '<b>' . $match['ext2'] . '</b> : <b>' . $match['ext3'] . '</b>';
        echo '<br/><textarea rows="1" cols="2" name="text" >0</textarea> &nbsp; <textarea rows="1" cols="2" name="text2" >0</textarea>
		<br/><small>только цифры</small>
		</p>';
        echo '<p><input type="submit" name="change" value="сделать ставку"/></p>
		</form>';
        main();
    } else {
	
	    // на сделанную ранее ставку
    $stavka = mysql_query('select * from `ktp` where `tip`=\'5\' and `ext1`=\'' . $user_id .
        '\' and `ext2`=\'' . mysql_real_escape_string($_GET['id']) . '\'');
    if (mysql_num_rows($stavka) == 1) {
        echo v5('Вы уже сделали ставку на данный мачт');
    require_once ("incfiles/end.php");
    exit;
    }

        //проверяем на счет
        if (!is_numeric($_POST['text'])) {
            echo v5('Вы ввели не число');
            echo '<a href="?act=bet&amp;id=' . $_GET['id'] . '">Попытаться снова</a>';
            main();
                require('incfiles/end.php');
        }

        //проверяем на счет
        if (!is_numeric($_POST['text2'])) {
            echo v5('Вы ввели не число');
            echo '<a href="?act=bet&amp;id=' . $_GET['id'] . '">Попытаться снова</a>';
            main();
                require('incfiles/end.php');
        }

        //счет
        $schet = $_POST['text'] . ',' . $_POST['text2'];
        //вычисляем исход (победитель или ничья)
        $ishod = $_POST['text'] > $_POST['text2'] ? $match['ext1'] : $match['ext2'];
        $ishod = $_POST['text'] == $_POST['text2'] ? 0 : $ishod;

        //создаем ставку
        $c = mysql_fetch_assoc($comandos);
        mysql_query('insert into `ktp` set 
		`tip`=\'5\',
		`ext1`=\'' . mysql_real_escape_string($user_id) . '\',
		`ext2`=\'' . mysql_real_escape_string($_GET['id']) . '\',
		`ext3`=\'' . mysql_real_escape_string($schet) . '\',
		`ext4`=\'' . mysql_real_escape_string($ishod) . '\',
		`ext5`=\'' . mysql_real_escape_string($c['ext3']) . '\'
		');

        echo v6('Ставка сделана');
        main();
    }

} elseif ($_GET['act'] == 'betslist' and mysql_num_rows($comandos) == 1) {
    echo v1('Меню капитана: Ставки товарищей по команде');
    //проверяем является ли юзер капитаном
    $c = mysql_fetch_assoc($comandos);
    $q = mysql_query('select * from `ktp` where `id`=\'' . $c['ext3'] . '\' and `ext5`=\'' .
        $user_id . '\'');
    if (mysql_num_rows($q) == 0) {
        echo v5('Меню капитана вам не доступно');
        main();
            require('incfiles/end.php');
    }

    $sql = 'select * from `ktp` where `tip` = \'2\' and `ext4` = \'0\' ';
    $sql = mysql_query($sql);

    while ($m = mysql_fetch_assoc($sql)) {

        echo v6($m['ext2'] . ' vs ' . $m['ext3']);

        //Выводим ставки товарищей
        $sql2 = 'select * from `ktp` where `tip` = \'5\' and `ext2` = \'' . $m['id'] . '\' and `ext5` = \'' .
            $c['ext3'] . '\'';
        $sql2 = mysql_query($sql2);
        if (mysql_num_rows($sql2) == 0)
            echo '<ul><li>Ставок нет</li></ul>';

        else {

            echo '<ul>';
            while ($bet = mysql_fetch_assoc($sql2)) {

                echo '<li>' . v7(unik($bet['ext1']) . ' ' . $bet['ext3']) . '</li>';

            }
            echo '</ul>';

        }


    }


    main();
        require('incfiles/end.php');
} elseif ($_GET['act'] == 'chat' and mysql_num_rows($comandos) == 1) {

    echo v1('Командный чат');

    //разгерметизация
    $comandos = mysql_fetch_assoc($comandos);

    //в . сообщения чата
    $mes = mysql_query('select * from `ktp` where `tip`=\'3\' and `ext3`=\'' . $comandos['ext3'] .
        '\' order by `ext1` Desc');
    if (!isset($_POST['change'])) {

        //Сообщений нет
        if (mysql_num_rows($mes) == 0) {
            echo v6('Пока сообщений в чате нет');
        } else {
            while ($m = mysql_fetch_row($mes)) {
                chat($m[3], $m[2], $m[5], $m[0]);
            }
        }
        //если юзер не в бане
        if (empty($ban)) {
            echo '<form action="?act=chat" method="POST">';
            echo '<p>Ваше сообщение:<br/>
		<textarea rows="3" cols="50" name="text" ></textarea><br/>
		<small>макс. 300 симв.</small>
		</p>';
            echo '<p><input type="submit" name="change" value="отправить"/></p>
		</form>';
        }
        main();
    } else {

        //проверяем юзера на бан
        if (!empty($ban)) {
            echo v5('Вы забанены, и не можете писать сообщения');
            echo '<a href="?act=chat">Вернуться назад</a>';
            main();
                require('incfiles/end.php');
        }

        //проверяем пустоту сообщения
        if (empty($_POST['text'])) {
            echo v5('Вы не заполнили поле сообщения');
            echo '<a href="?act=chat">Попытаться снова</a>';
            main();
                require('incfiles/end.php');
        }
        //проверяем длину сообщения
        if (mb_strlen($_POST['text']) > 300) {
            echo v5('Вы превысили максимальную длину сообщения (' . mb_strlen($_POST['text']) .
                ' &lt; 300)');
            echo '<a href="?act=chat">Попытаться снова</a>';
            main();
                require('incfiles/end.php');
        }

        //добавляем сообщение
        mysql_query('insert into `ktp` set 
		`tip`=\'3\',
		`ext1`=\'' . mysql_real_escape_string($realtime) . '\',
		`ext2`=\'' . mysql_real_escape_string($user_id) . '\',
		`ext3`=\'' . mysql_real_escape_string($comandos['ext3']) . '\',
		`ext4`=\'' . mysql_real_escape_string(html($_POST['text'])) . '\'
		');

        //удаляем более раннее сообщение
        if (mysql_num_rows($mes) > 19) {
            mysql_query('delete from `ktp` where `ext2`=\'' . $comandos[0] . '\' and `tip`=\'3\' order by `ext3` limit 1');
        }
        echo v6('Сообщение добавлено');
        echo '<a href="?act=chat">В чат</a>';
        main();
    }

} elseif ($_GET['act'] == 'list_bet_result' and ADMIN) {

    echo v1('Список матчей без результатов');
    //список матчей без результатов
    $q = mysql_query('select * from `ktp` where `tip`=\'2\' and `ext4`=\'0\'');
    //если матчей нету
    if (mysql_num_rows($q) == 0) {
        echo v6('Матчей нет, результаты вынесены. Все чики пуки )');
    }
    //матчи есть
    else {
        while ($m = mysql_fetch_assoc($q)) {
            echo v8($m['ext2'] . ' vs ' . $m['ext3'] . ' <a href="?act=bet_result&amp;id=' .
                $m['id'] . '">Вынести результат</a><br/>');
        }
    }
    main();
} elseif ($_GET['act'] == 'bet_result' and mysql_num_rows($comandos) == 1 and
isset($_GET['id'])) {

    //проверка ид.а
    //на существование и верный тип
    $q = mysql_query('select * from `ktp` where `tip`=\'2\' and `id`=\'' .
        mysql_real_escape_string($_GET['id']) . '\'');
    if (!mysql_num_rows($q)) {
        echo v5('Не верные данные');
        main();
            require('incfiles/end.php');
    }

    $match = mysql_fetch_assoc($q);

    //на уже вынесенный результат
    if ($match['ext4'] !== '0') {
        echo v5('Результат матча уже вынесен');
        main();
            require('incfiles/end.php');
    }

    if (!isset($_POST['change'])) {
        echo v1('Выносим результат ! <br/> ' . $match['ext2'] . ' vs ' . $match['ext3']);
        echo '<form action="?act=bet_result&amp;id=' . $_GET['id'] . '" method="POST">';
        echo '<p>Введите результат (счет)<br/>';
        echo '<b>' . $match['ext2'] . '</b> : <b>' . $match['ext3'] . '</b>';
        echo '<br/><textarea rows="1" cols="2" name="text" >0</textarea> &nbsp; <textarea rows="1" cols="2" name="text2" >0</textarea>
		<br/><small>только цифры, проверяйте правильность данных</small>
		</p>';
        echo '<p><input type="submit" name="change" value="вынести результат"/></p>
		</form>';
        main();
    } else {

        //проверяем на счет
        if (!is_numeric($_POST['text'])) {
            echo v5('Вы ввели не число');
            echo '<a href="?act=bet_result&amp;id=' . $_GET['id'] . '">Попытаться снова</a>';
            main();
                require('incfiles/end.php');
        }

        //проверяем на счет
        if (!is_numeric($_POST['text2'])) {
            echo v5('Вы ввели не число');
            echo '<a href="?act=bet_result&amp;id=' . $_GET['id'] . '">Попытаться снова</a>';
            main();
                require('incfiles/end.php');
        }

        //счет
        $schet = $_POST['text'] . ',' . $_POST['text2'];
        //вычисляем исход (победитель или ничья)
        $ishod = $_POST['text'] > $_POST['text2'] ? $match['ext1'] : $match['ext2'];
        $ishod = $_POST['text'] == $_POST['text2'] ? 0 : $ishod;

        //обновляем ячейку матча
        mysql_query('update `ktp` set 
        `ext4`=\'' . mysql_real_escape_string($schet) . '\'
        where `id`=\'' . $match['id'] . '\'
        ');
        //выносим баллы за правильно угаданный счет и исход

        /*
        // юзерам (счет)
        $points = mysql_real_escape_string($ochki['result']);
        $q = mysql_query('select * from `ktp` where `tip`=\'5\' and `ext2`=\''.$match['id'].'\' and `ext3`=\''.$schet.'\'');
        while ( $u = mysql_fetch_assoc($q) ){
        //добавляем очки
        mysql_query('update `ktp`
        set `ext1`=`ext1`+'.$points.' 
        where `ext2`= \''.$u['ext1'].'\' and `tip`=\'4\'');
        }
        // юзерам (исход)
        $points = mysql_real_escape_string($ochki['ishod']);
        $q = mysql_query('select * from `ktp` where `tip`=\'5\' and `ext2`=\''.$match['id'].'\' and `ext3`<>\''.$schet.'\' and `ext4`=\''.$ishod.'\'');
        while ( $u = mysql_fetch_assoc($q) ){
        //добавляем очки
        mysql_query('update `ktp`
        set `ext1`=`ext1`+\''.$points.'\'
        where `ext2`=\''.$u['ext1'].'\' and `tip`=\'4\'');
        }
        */
        $rez1 = intval($_POST['text']);
        $rez2 = intval($_POST['text2']);

        $req = mysql_query("SELECT * FROM `ktp` WHERE `tip`=5 AND `ext2`='" . $match['id'] .
            "' ;");


        while ($res = mysql_fetch_array($req)) {
            $rez = explode(',', $res['ext3']);

            if ($rez1 > $rez2) {

                if ($rez[0] == $rez1 && $rez[1] == $rez2) {
                    #счет
                    // обновляем счет пользователя +5
                    mysql_query("UPDATE `ktp` SET `ext1`=`ext1`+5 WHERE `ext2`='" . $res['ext1'] .
                        "'  and `tip`=4;");
                    echo $u['ext1'];
                } elseif (($rez[0] - $rez[1]) == ($rez1 - $rez2)) {
                    #Разница
                    mysql_query("UPDATE `ktp` SET `ext1`=`ext1`+3 WHERE `ext2`='" . $res['ext1'] .
                        "' and `tip`=4;");
                } elseif ($rez[0] > $rez[1]) {
                    #Исход
                    // обновляем счет пользователя +1
                    mysql_query("UPDATE `ktp` SET `ext1`=`ext1`+1 WHERE `ext2`='" . $res['ext1'] .
                        "'  and `tip`=4;");

                }


            } elseif ($rez1 < $rez2) {
                if ($rez[0] == $rez1 && $rez[1] == $rez2) {
                    #счет
                    mysql_query("UPDATE `ktp` SET `ext1`=`ext1`+5 WHERE `ext2`='" . $res['ext1'] .
                        "' and `tip`=4;");
                } elseif (($rez[1] - $rez[0]) == ($rez2 - $rez1)) {
                    #Разница
                    mysql_query("UPDATE `ktp` SET `ext1`=`ext1`+3 WHERE `ext2`='" . $res['ext1'] .
                        "' and `tip`=4;");
                } elseif ($rez[0] < $rez[1]) {
                    #Исход
                    mysql_query("UPDATE `ktp` SET `ext1`=`ext1`+1 WHERE `ext2`='" . $res['ext1'] .
                        "' and `tip`=4;");
                }

            } else {

                if ($rez[0] == $rez1 && $rez[1] == $rez2) {
                    // тут если равно
                    mysql_query("UPDATE `ktp` SET `ext1`=`ext1`+5 WHERE `ext2`='" . $res['ext1'] .
                        "' and `tip`=4;");
                } elseif ($rez[0] == $rez[1]) {
                    // тут если угадал исход
                    mysql_query("UPDATE `ktp` SET `ext1`=`ext1`+3 WHERE `ext2`='" . $res['ext1'] .
                        "' and `tip`=4;");
                }

            }
        }


        //командам (счет и исход)
        $points = mysql_real_escape_string($ochki['result']);
        $q = mysql_query('select * from `ktp` where `tip`=\'1\'');
        while ($c = mysql_fetch_assoc($q)) {
            //вычисляем количество юзеров команды угадавших результат
            $u = mysql_fetch_row(mysql_query('select count(*) from `ktp` where `tip`=\'5\' and `ext2`=\'' .
                $match['id'] . '\' and `ext5`=\'' . $c['id'] . '\' and `ext3`=\'' . $schet . '\''));
            //добавляем очки
            mysql_query('update `ktp`
					set `ext1`=`ext1`+' . $points * $u[0] . ' 
					where `id`= \'' . $c['id'] . '\' ');
        }
        //командам (исход)
        $points = mysql_real_escape_string($ochki['ishod']);
        $q = mysql_query('select * from `ktp` where `tip`=1');
        while ($c = mysql_fetch_assoc($q)) {
            //вычисляем количество юзеров команды угадавших результат
            $u = mysql_fetch_row(mysql_query('select count(*) from `ktp` where `tip`=\'5\' and `ext2`=\'' .
                $match['id'] . '\' and `ext5`=\'' . $c['id'] . '\' and `ext3`<>\'' . $schet . '\' and `ext4`=\'' .
                $ishod . '\''));
            //добавляем очки
            mysql_query('update `ktp`
					set `ext1`=`ext1`+' . $points * $u[0] . ' 
					where `id`= \'' . $c['id'] . '\' ');
        }

        echo v6('Результат вынесен, баллы розданы');
        main();
    }

} elseif ($_GET['act'] == 'delmes' and ADMIN) {
    mysql_query('delete from `ktp` where `tip`=\'3\' and `id`=\'' .
        mysql_real_escape_string($_GET['id']) . '\'');
    echo v6('Сообщение удалено');
    echo v7('<a href="?act=chat">В чат</a>');
    main();
        require('incfiles/end.php');
} elseif ($_GET['act'] == 'goodbuycomand' and mysql_num_rows($comandos) == 1) {

    echo v1('Прощай команда ..');
    //нет соглашение
    if (!isset($_GET['ok'])) {
        echo v8('Покинув команду вы сможете вступить в новую команду, но ваши очки обнулятся и вашу карьеру вам придется начать заново.');
        echo v7('Вы уверены что хотите покинуть команду? <a href="?act=goodbuycomand&amp;ok">Уверен</a>');
    }
    //удаление
    else {
        $c = mysql_fetch_assoc($comandos);
        //удаляем метку капитана, если он им является
        mysql_query('update `ktp` set `ext5`=\'0\' where `tip`=\'1\' and `ext5`=\'' . $user_id .
            '\'');
        //удаляем очки команды, которые заработал юзер
        mysql_query('update `ktp` set `ext1`=`ext1`-\'' . $c['ext1'] . '\' where `tip`=\'1\' and `id`=\'' .
            $c['ext3'] . '\'');
        //удаляем самого юзера
        mysql_query('delete from `ktp` where `id`=\'' . $c['id'] . '\'');

        echo v6('Вы успешно покинули команду');

    }
    main();
        require('incfiles/end.php');
} elseif ($_GET['act'] == 'myteam' and mysql_num_rows($comandos) == 1) {

    $c = mysql_fetch_assoc($comandos);

    $comand_name = mysql_fetch_row(mysql_query('select `ext2`,`ext5` from `ktp` where `id`=\'' .
        $c['ext3'] . '\''));

    echo v1('Команда ' . $comand_name[0] . ' (капитан: ' . unik($comand_name[1]) .
        ')');
    //выводим список участников
    $q = mysql_query('select * from `ktp` where `tip`=\'4\' and `ext3`=\'' . $c['ext3'] .
        '\' order by `ext1` desc');

    while ($u = mysql_fetch_assoc($q)) {
        echo v7(unik($u['ext2']) . ' - ' . $u['ext1'] . ' очков');
    }

    main();
        require('incfiles/end.php');
} elseif ($_GET['act'] == 'captain' and mysql_num_rows($comandos) == 1) {

    echo v1('Меню капитана');
    //проверяем является ли юзер капитаном
    $c = mysql_fetch_assoc($comandos);
    $q = mysql_query('select * from `ktp` where `id`=\'' . $c['ext3'] . '\' and `ext5`=\'' .
        $user_id . '\'');
    if (mysql_num_rows($q) == 0) {
        echo v5('Меню капитана вам не доступно');
        main();
            require('incfiles/end.php');
    }

    //если выбрано удаление
    if (isset($_GET['del']) and is_numeric($_GET['del'])) {
        $comandos = mysql_query('select * from `ktp` where `tip`=\'4\' and `ext2`=\'' .
            mysql_real_escape_string($_GET['del']) . '\'');
        $c2 = mysql_fetch_assoc($comandos);
        //удаляем метку капитана, если он им является
        mysql_query('update `ktp` set `ext5`=\'0\' where `tip`=\'1\' and `ext5`=\'' .
            mysql_real_escape_string($_GET['del']) . '\'');
        //удаляем очки команды, которые заработал юзер
        mysql_query('update `ktp` set `ext1`=`ext1`-\'' . $c2['ext1'] . '\' where `tip`=\'1\' and `id`=\'' .
            $c2['ext3'] . '\'');
        //удаляем самого юзера
        mysql_query('delete from `ktp` where `id`=\'' . $c2['id'] . '\'');
        echo v6('Юзер удален');
    }

    $comand_name = mysql_fetch_row(mysql_query('select `ext2`,`ext5` from `ktp` where `id`=\'' .
        $c['ext3'] . '\''));

    echo v1('Команда ' . $comand_name[0] . ' (капитан: ' . unik($comand_name[1]) .
        ')');
    //выводим список участников
    $q = mysql_query('select * from `ktp` where `tip`=\'4\' and `ext3`=\'' . $c['ext3'] .
        '\' order by `ext1` desc');

    while ($u = mysql_fetch_assoc($q)) {
        echo v7(unik($u['ext2']) . ' - ' . $u['ext1'] . ' очков' .
            ' <a href="?act=captain&amp;del=' . $u['ext2'] . '">[убрать из команды]</a>');
    }

    main();
        require('incfiles/end.php');
} elseif ($_GET['act'] == 'izmteams' and ADMIN) {
    //если выбрано удаление юзера
    if (isset($_GET['deluser']) and is_numeric($_GET['deluser'])) {
        $comandos = mysql_query('select * from `ktp` where `tip`=\'4\' and `ext2`=\'' .
            mysql_real_escape_string($_GET['deluser']) . '\'');
        $c2 = mysql_fetch_assoc($comandos);
        //удаляем метку капитана, если он им является
        mysql_query('update `ktp` set `ext5`=\'0\' where `tip`=\'1\' and `ext5`=\'' .
            mysql_real_escape_string($_GET['del']) . '\'');
        //удаляем очки команды, которые заработал юзер
        mysql_query('update `ktp` set `ext1`=`ext1`-\'' . $c2['ext1'] . '\' where `tip`=\'1\' and `id`=\'' .
            $c2['ext3'] . '\'');
        //удаляем самого юзера
        mysql_query('delete from `ktp` where `id`=\'' . $c2['id'] . '\'');
        echo v6('Юзер удален');
    }
    //изменение команд
    if (isset($_GET['izm']) and isset($_GET['id']) and is_numeric($_GET['id'])) {
        echo v1('Изменяем команду');
        //проверяем цифероверность
        $comand = mysql_query('select * from `ktp` where `tip` = \'1\' and `id`=\'' .
            mysql_real_escape_string($_GET['id']) . '\' ');
        if (!mysql_num_rows($comand)) {
            echo v5('Ошибка. Команда не найдена');
            main();
                require('incfiles/end.php');
        }
        //не нажато
        if (!isset($_POST['change'])) {
            $c = mysql_fetch_assoc($comand);
            echo '<form action="?act=izmteams&amp;izm&amp;id=' . $_GET['id'] .
                '" method="POST">';
            echo '<p>Название команды<br/>
			<textarea rows="1" cols="50" name="text" >' . $c['ext2'] . '</textarea><br/>
			<small>мин. 5 * макс. 50 симв.</small>
			</p>';
            //выбор капитана
            echo '<p>Смена капитана</p><select name="text2">';
            echo '<option value="default">Как было ' . ($c['ext5'] ? '(капитан ' . unik($c['ext5']) .
                ')' : '(нет кап.)'), '</option>';
            echo '<option value="notcap">Без капитана</option>';

            $q = mysql_query('select * from `ktp` where `tip`=\'4\' and `ext3`=\'' . $c['id'] .
                '\' order by `ext1` desc');
            while ($c = mysql_fetch_assoc($q)) {
                echo '<option value="' . $c['ext2'] . '">' . unik($c['ext2']) . '</option>';
            }
            echo '</select>';
            echo '<p><input type="submit" name="change" value="изменить команду"/></p>
			</form>';
        }
        //нажато
        else {
            //проверяем пустоту в названии
            if (empty($_POST['text'])) {
                echo v5('Вы не заполнили название создаваемой команды');
                echo '<a href="?act=izmteams&amp;izm&amp;id=' . $_GET['id'] .
                    '">Попытаться снова</a>';
                main();
                    require('incfiles/end.php');
            }
            //проверяем длину названия
            if (mb_strlen($_POST['text']) > 50) {
                echo v5('Вы превысили максимальную длину названия команды (' . mb_strlen($_POST['text']) .
                    ' &lt; 50)');
                echo '<a href="?act=izmteams&amp;izm&amp;id=' . $_GET['id'] .
                    '">Попытаться снова</a>';
                main();
                    require('incfiles/end.php');
            }
            if (mb_strlen($_POST['text']) < 5) {
                echo v5('Вы не набрали минимальную длину названия команды (' . mb_strlen($_POST['text']) .
                    ' &lt; 5)');
                echo '<a href="?act=izmteams&amp;izm&amp;id=' . $_GET['id'] .
                    '">Попытаться снова</a>';
                main();
                    require('incfiles/end.php');
            }

            //проверяем данные в команде

            //проверяем пустоту в названии
            if (empty($_POST['text2'])) {
                echo v5('Вы не выбрали ниодин пункт из смены капитана');
                echo '<a href="?act=izmteams&amp;izm&amp;id=' . $_GET['id'] .
                    '">Попытаться снова</a>';
                main();
                    require('incfiles/end.php');
            }

            if ($_POST['text2'] != 'default' and $_POST['text2'] != 'notcap' and !(is_numeric
                ($_POST['text2']))) {
                echo v5('Не верно выбран пункт из "смена капитана"');
                echo '<a href="?act=izmteams&amp;izm&amp;id=' . $_GET['id'] .
                    '">Попытаться снова</a>', $_POST['text2'];
                main();
                    require('incfiles/end.php');
            }

            $c = mysql_fetch_assoc($comand);
            if (is_numeric($_POST['text2'])) {
                $user = mysql_query('select * from `ktp` where `tip`=\'4\' and `ext3`=\'' . $c['id'] .
                    '\' and `ext2`=\'' . mysql_real_escape_string($_POST['text2']) . '\'');
                if (mysql_num_rows($user) == 0) {
                    echo v5('Не верно выбран юзер из "смена капитана"');
                    echo '<a href="?act=izmteams&amp;izm&amp;id=' . $_GET['id'] .
                        '">Попытаться снова</a>';
                    main();
                        require('incfiles/end.php');
                }
            }

            $_POST['text2'] = ($_POST['text2'] == 'notcap' ? 0 : $_POST['text2']);

            if ($_POST['text2'] != 'default')
                $_POST['text2'] = ', `ext5`=\'' . mysql_real_escape_string($_POST['text2']) . '\' ';
            else
                $_POST['text2'] = '';

            mysql_query('update `ktp` set
				`ext2`=\'' . mysql_real_escape_string($_POST['text']) . '\'
				' . $_POST['text2'] . '
				where `id`=\'' . $c['id'] . '\'');
            echo v6('Команда изменена');
        }

    } elseif (isset($_GET['del']) and isset($_GET['id']) and is_numeric($_GET['id'])) {
        echo v1('Удаляем команду');

        //проверяем цифероверность
        $comand = mysql_query('select * from `ktp` where `tip` = \'1\' and `id`=\'' .
            mysql_real_escape_string($_GET['id']) . '\' ');
        if (!mysql_num_rows($comand)) {
            echo v5('Ошибка. Команда не найдена');
            main();
                require('incfiles/end.php');
        }

        $c = mysql_fetch_assoc($comand);

        //удаляем команду
        mysql_query('delete from `ktp` where `tip`=\'1\' and `id`=\'' . $c['id'] . '\'');
        //удаляем игроков команды
        mysql_query('delete from `ktp` where `tip`=\'4\' and `ext3`=\'' . $c['id'] . '\'');
        //удаляем ставки игроков команды
        mysql_query('delete from `ktp` where `tip`=\'5\' and `ext5`=\'' . $c['id'] . '\'');
        //удаляем сообщения чата команды
        mysql_query('delete from `ktp` where `tip`=\'3\' and `ext3`=\'' . $c['id'] . '\'');

        echo v6('Команда удалена');

    } else {
        echo v1('Листинг всех команд');

        $comands = mysql_query('Select * from `ktp` where `tip`=\'1\' order by `ext1` Asc');
        //выводим команды
        while ($c = mysql_fetch_assoc($comands)) {

            echo v8($c['ext2'] . ($c['ext5'] ? ' (капитан: ' . unik($c['ext5']) . ' )' :
                '(нет капитана)') . ' <a href="?act=izmteams&amp;izm&amp;id=' . $c['id'] .
                '">Изм.</a> / <a href="?act=izmteams&amp;del&amp;id=' . $c['id'] .
                '">Уд.</a> <br/> Всего очков: ' . $c['ext1']);
            // выводим лучших игроков
            $q = mysql_query('select * from `ktp` where `tip`=\'4\' and `ext3`=\'' . $c['id'] .
                '\' order by `ext1` desc');
            //если игроков нету
            if (mysql_num_rows($q) == 0) {
                echo '<small>игроков в команде нет</small>';
            }
            //если есть
            else {
                echo '<small><ul><li>Игроки команды</li>';
                while ($u = mysql_fetch_assoc($q)) {
                    echo '<li>' . v7(unik($u['ext2']) . ' (очков: ' . $u['ext1'] .
                        ') <a href="?act=izmteams&amp;deluser=' . $u['ext2'] .
                        '">[убрать из команды]</a> ') . '</li>';
                }
                echo '</ul></small>';
            }
        }
    }
    main();
        require('incfiles/end.php');
} elseif ($_GET['act'] == 'ccleaner' and ADMIN) {

    echo v1('Чистка');

    echo v7('<small>Очищает таблицу от чата, ставок и матчей</small>');
    echo v7('<small>Рекомендуется к использованию 1 раз в полгода</small>');
    echo v7('<small>(очищаются все данные, в случае чего создайте бэкап)</small>');

    if (isset($_GET['chat'])) {
        mysql_query('delete from `ktp` where `tip` = \'3\'');
        echo v6('Чат очищен');
    }
    if (isset($_GET['match'])) {
        mysql_query('delete from `ktp` where `tip` = \'2\'');
        echo v6('Матчи удалены');
    }
    if (isset($_GET['bet'])) {
        mysql_query('delete from `ktp` where `tip` = \'5\'');
        echo v6('Ставки уничтожены');
    }
    if (isset($_GET['stat'])) {
        mysql_query('Update `ktp` set `ext1` = \'0\' where `tip` = \'4\' or `tip` = \'1\'');
        echo v6('Статистика команд обнулена');
    }

    $chat = mysql_result(mysql_query('select count(*) from `ktp` where `tip` = \'3\''),
        0);
    $match = mysql_result(mysql_query('select count(*) from `ktp` where `tip` = \'2\''),
        0);
    $bet = mysql_result(mysql_query('select count(*) from `ktp` where `tip` = \'5\''),
        0);

    echo v1('Статистика:');
    echo '<ul>' . '<li>Чат: ' . $chat . ' записей</li>' . '<li>Матчи: ' . $match .
        ' записей</li>' . '<li>Ставки: ' . $bet . ' записей</li>' . '<li>-</li>' .
        '<li>Итого: ' . ($bet + $match + $chat) . ' записей</li>' . '</ul>';

    echo v1('Операции');
    echo '<ul>' . '<li>Чат: <a href="?act=ccleaner&amp;chat">очистить</a></li>' .
        '<li>Матчи: <a href="?act=ccleaner&amp;match">очистить</a></li>' .
        '<li>Ставки: <a href="?act=ccleaner&amp;bet">очистить</a></li>' .
        '<li>Очки команд/игроков: <a href="?act=ccleaner&amp;stat">очистить</a></li>' .
        '<li><a href="?act=ccleaner&amp;chat&amp;match&amp;bet&amp;stat">Удалить все</a></li>' .
        '</ul>';


    main();
        require('incfiles/end.php');
} elseif ($_GET['act'] == 'statplayer' and mysql_num_rows($comandos) == 1) {

    $kolvo = 10; // Максимальное количество


    // выводим лучших игроков
    $q = mysql_query('select * from `ktp` where `tip`=\'4\'  order by `ext1` desc Limit ' .
        $kolvo);

    echo '<small><ul>';
    while ($u = mysql_fetch_assoc($q)) {
        echo '<li>' . v7(unik($u['ext2']) . ' (очков: ' . $u['ext1'] . ')') . '</li>';
    }
    echo '</ul></small>';


    main();

} else {

    echo v1('Футбольный КТП');

    //для не вступившего в команду
    if (!mysql_num_rows($comandos)) {
        echo v5('Вы не можете участвовать в КТП, пока не вступите в команду');
        echo v5('<a href="?act=inter_comand">Вступить в команду</a>');
    }
    //для вступившего
    else {

        //матчи для ставок
        $match = mysql_query('select * from `ktp` where `tip`=\'2\' and `ext4`=\'0\' and `ext3` > \'' .
            $realtime . '\'');
        // ** Необходима смена алгоритма ( иной запрос )

        //матчей нет
        if (mysql_num_rows($match) == 0) {
            echo v5('На данный момент нет активных матчей для ставок');
        }
        //выводим матчи
        else {
            //матчи и ставки
            $stavki = array();
            $q = mysql_query('select `ext2` from `ktp` where `tip`=\'5\' and `ext1`=\'' .
                mysql_real_escape_string($user_id) . '\'');
            while ($st = mysql_fetch_row($q)) {
                $stavki[] = $st[0];
            }
            //массив
            while ($m = mysql_fetch_row($match)) {
                if (!in_array($m[0], $stavki))
                    $t .= v8($m[3] . ' vs ' . $m[4] . '<br/><a href="?act=bet&amp;id=' . $m[0] .
                        '">Сделать ставку</a> <small>(до ' . date("d.m.Y / H:i", $m[2] + $set_user['sdvig'] *
                        3600) . ')</small>');
            }
            //матчи есть
            if (@$t)
                echo '<fieldset><legend>Матчи для ставки</legend>' . $t . '</fieldset>';
            //матчей нет
            else
                echo v6('Вы уже сделали ставки на все доступные матчи');
        }
        echo v8('- <a href="?act=chat">Командный Чат</a>');
        echo v8('- <a href="?act=myteam">Состав моей команды</a>');
        echo v8('- <a href="?act=statcomand">Статистика команд</a>');
        echo v8('- <a href="?act=statplayer">Статистика игроков</a>');
        echo v8('- <a href="?act=statraund">Статистика матчей</a>');

        //меню капитана
        //вычисляем является ли юзер капитаном команды
        $c = mysql_fetch_assoc($comandos);
        $q = mysql_query('select * from `ktp` where `id`=\'' . $c['ext3'] . '\' and `ext5`=\'' .
            $user_id . '\'');
        if (mysql_num_rows($q) == 1) {
            echo v8('- <a href="?act=captain">Меню капитана</a>');
            echo v8('- <a href="?act=betslist">Ставки товарищей по команде</a>');
        }
        echo v8('- <a href="?act=goodbuycomand">Покинуть команду</a>');

    }

    //меню админа
    if (ADMIN) {
        echo '<p><div class="func">';
        echo v1('Админ панель');
        echo v7('<a href="?act=create_comand">Создать команду</a>');
        echo v7('<a href="?act=create_raund">Создать матч</a>');
        echo v7('<a href="?act=list_bet_result">Вынести результаты</a>');
        echo v7('<a href="?act=izmteams">Изменение команд</a>');
        echo v7('<a href="?act=ccleaner">Чистка</a>');
        echo '</div></p>';
    }
}


require_once ('incfiles/end.php');

?>