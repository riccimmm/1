<?php
$dhost='localhost';
$dlog='db_gorevo';
$dpass='NnXUFgQL';
$dbase='db_gorevo';

require_once"../template/start.php";
require_once"../template/regglobals.php";
require_once"../template/config.php";
require_once"../template/functions.php";
require_once"../template/antidos.php";
require_once"../template/cookies.php";
require_once"../template/gzip.php";
require_once"../template/header.php";
require_once"../template/referer.php";
include_once"../themes/$config_themes/index.php";
include_once"../template/isset.php";
mysql_connect($dhost, $dlog, $dpass) or exit ("Could not connect to MySQL!");

mysql_select_db ($dbase) or exit ("Could not select MySQL database!"); mysql_query("SET NAMES 'cp1251_general_ci'
COLLATE 'utf8'");
function prov($per,$skol=false){
$per=stripslashes(htmlspecialchars(trim($per),ENT_QUOTES,'UTF-8'));
$per=mysql_real_escape_string($per);
if(!empty($skol)){$per=mb_substr($per,0,$skol,'UTF-8');}
return $per;
}
function strpage($page, $posts, $total, $start, $reqpage=""){

if ($page != 0) echo '<a href="'.$start.'?'.$reqpage.'page='.($page - $posts).'">&lt;-Назад</a> ';
else echo '&lt;-Назад';

echo ' | ';
if ($total > $page + $posts)
echo ' <a href="'.$start.'?'.$reqpage.'page='.($page + $posts).'">Далее-&gt;</a>';
else echo 'Далее-&gt;';
if($total>0){

$ba = ceil($total/$posts);
$ba2 = $ba*$posts-$posts;
echo '<br>Стр:';
$asd = $page-($posts*3);
$asd2 = $page+($posts*4);

if($asd<$total && $asd>0) echo ' <a href="'.$start.'?'.$reqpage.'page=0">1</a> ... ';

for($i=$asd; $i<$asd2;){
if($i<$total && $i>=0){
$ii = floor(1+$i/$posts);
if ($page==$i) echo ' <b>['.$ii.']</b>';
else echo ' <a href="'.$start.'?'.$reqpage.'page='.$i.'">'.$ii.'</a>';
}
$i=$i+$posts;
}
if($asd2<$total) echo ' ... <a href="'.$start.'?'.$reqpage.'page='.$ba2.'">'.$ba.'</a>';
}}
?>