<?php
include'header.php';

if ($provlog==$_SESSION['log'] && $provpar==md5($_SESSION['par']) && $_SESSION['log']!="" && md5($_SESSION['par'])!=""){
switch($_GET['act']){
default:
$qg1=mysql_num_rows(mysql_query("SELECT * FROM `ktp_club` WHERE `uz`='$log' LIMIT 1"));
$qg2=mysql_num_rows(mysql_query("SELECT * FROM `ktp_user` WHERE `uz`='$log' LIMIT 1"));
if($qg2==0 or $qg1==0){echo'У вас нет команды';
echo'<br><a href="cabinet.php?act=search_club">Найти команду</a><br><a href="cabinet.php?act=newclub">Создать свою команду</a>';}else{
$erq=mysql_num_rows(mysql_query("SELECT * FROM `ktp_club` WHERE `uz`='$log' LIMIT 1")); if($erq==1){
$qe=mysql_fetch_assoc(mysql_query("SELECT `id` FROM `ktp_club` WHERE `uz`='$log' LIMIT 1"));  $kolz=mysql_result(mysql_query("SELECT COUNT(*) FROM `ktp_vstup` WHERE `id_club`='".$qe['id']."'"),0); echo'<a href="cabinet.php?act=deluser">Уволить игрока</a><br><a href="cabinet.php?act=vstup">Заявки на вступление</a> ['.$kolz.']<br>';} $da=mysql_fetch_assoc(mysql_query("SELECT * FROM `ktp_user` WHERE `uz`='$log' LIMIT 1")); $cl=mysql_fetch_assoc(mysql_query("SELECT `name` FROM `ktp_club` WHERE `id`='".$da['id_club']."' LIMIT 1"));
echo'<b>Команда:</b> <a href="info.php?id_club='.$da['id_club'].'">['.$cl['name'].']</a><br>'; $gm=mysql_num_rows(mysql_query("SELECT * FROM `ktp_club` WHERE `uz`='$log' AND `id`='".$da['id_club']."' LIMIT 1"));
if($gm==1){echo'<font color="red">[Капитан]</font><br>';}
echo'<b>Очкoв:</b> '.$da['ochki'].'<br><b>Ставок:</b> '.$da['stavki'].'<br><b>Точных счетов:</b> '.$da['t1'].'<br><b>Точных исходов:</b> '.$da['t2'].'<br><b>Проигрышей:</b> '.$da['t3'].'<br><b>Дата реги:</b> '.date_fixed($da['time']).'<br>';
}
break;

case'newclub':
$qg1=mysql_num_rows(mysql_query("SELECT * FROM `ktp_club` WHERE `uz`='$log' LIMIT 1"));
$qg2=mysql_num_rows(mysql_query("SELECT * FROM `ktp_user` WHERE `uz`='$log' LIMIT 1"));
if($qg2==1 or $qg1==1){echo'У вас есть уже команда';
}else{ if(!empty($_POST['name']) and !empty($_POST['text'])){
$text=prov($_POST['text'],50);
$name=prov($_POST['name'],80);
mysql_query("INSERT INTO `ktp_club` SET `name`='$name', `abb`='$text', `uz`='$log', `time`='$sitetime'");

mysql_query("INSERT INTO `ktp_user` SET `id_club`='".mysql_insert_id()."', `uz`='$log', `time`='$sitetime'"); echo'Успешно создана!';
}else{
echo'<form action="cabinet.php?act=newclub" method="post">Название:<br><input type="text" name="name" size="18"><br>Аббривиатура:<br><textarea cols="20" rows="1" name="text"></textarea><br><input type="submit" value="Создать"/></form>';
}
} break;

case'search_club':
$qg1=mysql_num_rows(mysql_query("SELECT * FROM `ktp_club` WHERE `uz`='$log' LIMIT 1"));
$qg2=mysql_num_rows(mysql_query("SELECT * FROM `ktp_user` WHERE `uz`='$log' LIMIT 1"));
if($qg2==1 or $qg1==1){echo'У вас есть уже команда';
}else{
$id_club=(int)$_GET['id_club']; if($id_club==0 or $id_club==""){ echo'Команды куда можно подать заявку на вступление<br><br>';  $qq=mysql_query("SELECT * FROM `ktp_club`"); while($t=mysql_fetch_array($qq)){ $err=mysql_num_rows(mysql_query("SELECT * FROM `ktp_user` WHERE `id_club`='".$t['id']."'")); if($err<5){ echo'['.$err.'] '.$t['name'].'<br><a href="cabinet.php?act=search_club&id_club='.$t['id'].'">Подать заявку</a><br>'; } } }else{ if(mysql_num_rows(mysql_query("SELECT * FROM `ktp_club` WHERE `id`='$id_club' LIMIT 1"))==1){ mysql_query("INSERT INTO `ktp_vstup` SET `uz`='$log',`id_club`='$id_club',`time`='$sitetime'"); echo'Заявка отправлена';}else{echo'ERROR';}} } break;

 case'vstup': 
$erq=mysql_num_rows(mysql_query("SELECT * FROM `ktp_club` WHERE `uz`='$log' LIMIT 1")); if($erq==1){ 
$qe=mysql_fetch_assoc(mysql_query("SELECT `id` FROM `ktp_club` WHERE `uz`='$log' LIMIT 1")); $myy=mysql_query("SELECT * FROM `ktp_vstup` WHERE `id_club`='".$qe['id']."' ORDER BY `time` DESC"); if(mysql_num_rows($myy)==0){echo'Пусто';}else{echo'Хотят вступить:<br>'; while($u=mysql_fetch_array($myy)){echo'<a href="/pages/anketa.php?uz='.$u['uz'].'">'.$u['uz'].'</a><br><a href="cabinet.php?act=vstup2&amp;id='.$u['id'].'">Взять</a><br><a href="cabinet.php?act=vstup_del&amp;id='.$u['id'].'">Отклонить</a><br>'; }} }  break;   case'vstup2': 
$erq=mysql_num_rows(mysql_query("SELECT * FROM `ktp_club` WHERE `uz`='$log' LIMIT 1")); if($erq==1){ 
$qe=mysql_fetch_assoc(mysql_query("SELECT `id` FROM `ktp_club` WHERE `uz`='$log' LIMIT 1"));  $etr=mysql_num_rows(mysql_query("SELECT * FROM `ktp_user` WHERE `id_club`='".$qe['id']."'")); if($etr<5){$id=(int)$_GET['id']; $q=mysql_fetch_assoc(mysql_query("SELECT * FROM `ktp_vstup` WHERE `id`='$id' AND `id_club`='".$qe['id']."' LIMIT 1"));  mysql_query("INSERT INTO `ktp_user` SET `uz`='".$q['uz']."', `time`='$sitetime', `id_club`='".$qe['id']."'"); mysql_query("DELETE FROM `ktp_vstup` WHERE `id`='$id'"); echo'Пользователь успешно взят в команду';}else{echo'Ваша команда и так переполнена';}} break;
case'vstup_del': $id=(int)$_GET['id']; $erq=mysql_num_rows(mysql_query("SELECT * FROM `ktp_club` WHERE `uz`='$log' LIMIT 1")); if($erq==1){ 
$qe=mysql_fetch_assoc(mysql_query("SELECT `id` FROM `ktp_club` WHERE `uz`='$log' LIMIT 1"));  mysql_query("DELETE FROM `ktp_vstup` WHERE `id`='$id' AND `id_club`='".$qe['id']."'"); echo'Заявка отклонена'; } break;
case'deluser': $erq=mysql_num_rows(mysql_query("SELECT * FROM `ktp_club` WHERE `uz`='$log' LIMIT 1")); if($erq==1){  $id_user=(int)$_GET['id_user']; 
 if($id_user==0 or $id_user==""){
$qe=mysql_fetch_assoc(mysql_query("SELECT `id` FROM `ktp_club` WHERE `uz`='$log' LIMIT 1")); $daur=mysql_query("SELECT * FROM `ktp_user` WHERE `id_club`='".$qe['id']."' AND `uz`!='$log' ORDER BY `id` DESC");  if(mysql_num_rows($daur)==1){echo'В команде только вы';}else{ while($da=mysql_fetch_array($daur)){echo'<a href="info.php?id_user='.$da['id'].'">'.$da['uz'].'</a> <a href="cabinet.php?id='.$da['id'].'">[Уволить]</a><br>';}}  }else{ $d=mysql_fetch_assoc(mysql_query("SELECT `uz` FROM `ktp_user` WHERE `id`='$id' LIMIT 1")); $ed=mysql_num_rows(mysql_query("SELECT * FROM `ktp_user` WHERE `uz`='".$d['uz']."' LIMIT 1")); if($ed==0){ mysql_query("DELETE FROM `ktp_user` WHERE `id`='$id'"); echo'Успешно уволен!';}else{echo'ERROR';}} } break; }
}else{echo'Только для зарегистрированых!';}
include'footer.php'; ?>
