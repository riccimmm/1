<?php
include'header.php';
$id_club=(int)$_GET['id_club'];
$id_user=(int)$_GET['id_user'];
if(!empty($id_user) and !empty($id_club)){echo'Ошибка!!!';}else{
if($id_user!=0){
$erq=mysql_num_rows(mysql_query("SELECT * FROM `ktp_user` WHERE `id`='$id_user' LIMIT 1")); if($erq==1){
$da=mysql_fetch_assoc(mysql_query("SELECT * FROM `ktp_user` WHERE `id`='$id_user' LIMIT 1"));  echo'<b>Игрок: </b>'.$da['uz'].'<br><br>';
$cl=mysql_fetch_assoc(mysql_query("SELECT `name` FROM `ktp_club` WHERE `id`='".$da['id_club']."' LIMIT 1"));

echo'<b>Команда:</b> <a href="info.php?id_club='.$da['id_club'].'">['.$cl['name'].']</a><br>'; $gm=mysql_num_rows(mysql_query("SELECT * FROM `ktp_club` WHERE `id`='$id_user' AND `id`='".$da['id_club']."' LIMIT 1"));
if($gm==1){echo'<font color="red">[Капитан]</font><br>';}
echo'<b>Очкoв: </b>'.$da['ochki'].'<br><b>Ставок:</b> '.$da['stavki'].'<br><b>Точных счетов:</b> '.$da['t1'].'<br><b>Точных исходов:</b> '.$da['t2'].'<br><b>Проигрышей:</b> '.$da['t3'].'<br><b>Дата реги:</b> '.date_fixed($da['time']).'<br>';}else{echo'Нет такого игрока';}
}
if($id_club!=0){
$erq=mysql_num_rows(mysql_query("SELECT * FROM `ktp_club` WHERE `id`='$id_club' LIMIT 1")); if($erq==1){
$da=mysql_fetch_assoc(mysql_query("SELECT * FROM `ktp_club` WHERE `id`='$id_club' LIMIT 1"));
$quer=mysql_query("SELECT * FROM `ktp_user` WHERE `id_club`='$id_club'");
echo'<b>Команда:</b> <a href="info.php?id_club='.$id_club.'">'.$da['name'].'</a><br><b>Аббривиатура:</b> ['.$da['abb'].']<br><b>Игроки:</b> <br>';   while($data=mysql_fetch_array($quer)){echo'<a href="info.php?id_user='.$data['id'].'">'.$data['uz'].'</a> ';
if($data['uz']==$da['uz']){
echo'<font color="red">[Капитан]</font><br>';}else{echo'<br/>';}}
echo'<b>Очкoв:</b>  '.$da['ochki'].'<br><b>Ставок:</b> '.$da['stavki'].'<br><b>Точных счетов:</b> '.$da['t1'].'<br><b>Точных исходов:</b> '.$da['t2'].'<br><b>Проигрышей:</b> '.$da['t3'].'<br><b>Дата реги:</b> '.date_fixed($da['time']).'<br>';}else{echo'Нет такой команды';}
}
}
include'footer.php';
?>
