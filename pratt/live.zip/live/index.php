<?php
define('_IN_JOHNCMS', 1);
$headmod ="live";
$textl = 'LIVE Результаты';
$rootpath = '../';
require_once ("../incfiles/core.php");
require_once ("../incfiles/head.php");
header("Content-type:text/html; charset=utf-8");
$fid=$_GET['fid'];
$ch = curl_init("http://mobilesports.ru/live/$fid");
curl_setopt($ch, CURLOPT_TIMEOUT, 5);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Accept: text/html, application/xml, application/xhtml+xml, image/png, image/jpeg, image/gif, image/x-xbitmap, */*;', 'Accept-Language: ru, en, *;', 'Accept-Charset: iso-8859-1, utf-8, utf-16, *;', 'Accept-Encoding: identity;', 'Connection: close'));
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322)');
curl_setopt($ch, CURLOPT_REFERER, 'http://mobilesports.ru/live/');
$file = curl_exec($ch);
##############################################
$file = iconv("utf8", "UTF-8", $file);
$file=preg_replace('/<?xml(.*?)<div class=\"menu\">/si','',$file);
$file=preg_replace('/<div class="gmenu">(.*?)<\/html>/si','',$file);
$file = preg_replace('/<a href="http:\/\/mobileads.ru(.*?)<\/a>/si','',$file);
$file = preg_replace('/<a href="http:\/\/show.multiclick.ru(.*?)<\/a>/si','',$file);
echo $file;
require_once ("../incfiles/end.php");
?>